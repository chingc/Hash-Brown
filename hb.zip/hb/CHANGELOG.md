## 4.0
2013-05-01

- Massive code cleanup and restructuring.  Completely rewritten.


## 3.2
2011-03-20

- Use Python 3.2.


## 3.1
2011-01-07

- Documentation update.
- Changed
    - Display format of progress tracker.


## 3.0
2010-12-01

- Completely rewritten in functional style.
- First public release.


## 2.0
2010-07-26

- Completely rewritten to be more object oriented.
- Added
    - Recursive path expansion for Windows.
    - Mismatch counting.


## 1.0
2010-07-08

- First internal release.
